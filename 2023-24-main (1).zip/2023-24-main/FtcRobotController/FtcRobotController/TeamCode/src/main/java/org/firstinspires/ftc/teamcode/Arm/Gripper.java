package org.firstinspires.ftc.teamcode.Arm;

import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;

public class Gripper {
    private final ServoImplEx lGripper;
    private final ServoImplEx rGripper;
    private boolean gripperIsOpen;
    private int servoCountdown;
    private Gamepad gamepad = null;
    public String status = "";

    public Gripper(HardwareMap hardwareMap, Gamepad myGamepad){
        lGripper = hardwareMap.get(ServoImplEx.class, "leftGripper");
        lGripper.setPwmRange(new PwmControl.PwmRange(500, 2500));
        lGripper.scaleRange(0.2,0.45);
        rGripper = hardwareMap.get(ServoImplEx.class, "rightGripper");
        rGripper.setPwmRange(new PwmControl.PwmRange(500, 2500));
        rGripper.scaleRange(0.2,0.45);
        gamepad = myGamepad;
        lGripper.setDirection(Servo.Direction.FORWARD);
        rGripper.setDirection(Servo.Direction.REVERSE);

        // start closed
        gripperClose();
    }


    public void gripperOpen(){
        lGripper.setPosition(1.0);
        rGripper.setPosition(1.0);
        gripperIsOpen = true;
        servoCountdown = 200;
        status = "open";
    }
    public void gripperClose(){
        lGripper.setPosition(0.0);
        rGripper.setPosition(0.0);
        gripperIsOpen = false;
        servoCountdown = 200;
        status = "close";
    }
    public void loop() {

        if (servoCountdown>0){
            servoCountdown -= 1;
            return;
        }

        if (gamepad.a && !gripperIsOpen) {
            gripperOpen();
        }
        else if (gamepad.y && gripperIsOpen) {
            gripperClose();
        } else {
            status =  "idle";
        }
    }
}
