package org.firstinspires.ftc.teamcode.Arm;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class Shoulder {
    private final DcMotor shoulderMotor;
    private final Gamepad gamepad;
    public String status = "";
    private boolean stopPower;
    private final int powerNum = 1;

    public Shoulder(HardwareMap hardwareMap, Gamepad gamepad) {
        this.gamepad = gamepad;
        shoulderMotor = hardwareMap.get(DcMotor.class, "shoulderMotor");
        shoulderMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }

    public void loop() {
        if (gamepad.left_stick_y < -0.3) {
            moveDown();
        } else if (gamepad.left_stick_y > 0.3) {
            moveUp();
        } else {
            stop();
        }
    }

    public void moveUp() {
        shoulderMotor.setPower((gamepad.left_stick_y / powerNum));
        status = "Move Up";
    }

    public void moveDown() {
        shoulderMotor.setPower((gamepad.left_stick_y / powerNum));
        status = "Move Down";
    }

    public void move(double power)
    {
        shoulderMotor.setPower(power);
    }
    public void stop() {
        shoulderMotor.setPower(0);
    }
}
