package org.firstinspires.ftc.teamcode.Controller;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.Arm.Elbow;
import org.firstinspires.ftc.teamcode.Arm.Gripper;
import org.firstinspires.ftc.teamcode.Arm.Shoulder;
import org.firstinspires.ftc.teamcode.Arm.Wrist;
import org.firstinspires.ftc.teamcode.Movement.MoveDaRobot;

import java.util.Vector;

@TeleOp
public class MarvelsTeleOp extends OpMode {
    MoveDaRobot moveDaRobot;
    Shoulder shoulder;
    Wrist wrist;
    Gripper gripper;
    Elbow elbow;

    @Override
    public void init() {
        moveDaRobot = new MoveDaRobot(hardwareMap, telemetry, gamepad1);
        gripper = new Gripper(hardwareMap, gamepad2);
        shoulder = new Shoulder(hardwareMap, gamepad2);
        wrist = new Wrist(hardwareMap, gamepad2);
        elbow = new Elbow(hardwareMap, gamepad2);
        moveDaRobot.init();
    }

    @Override
    public void loop() {
        moveDaRobot.loop();
        gripper.loop();
        shoulder.loop();
        wrist.loop();
        elbow.loop();

        telemetry.addData("Shoulder: ", shoulder.status);
        telemetry.addData("Elbow:", elbow.status);
        telemetry.addData("Wrist: ", wrist.status);
        telemetry.addData("GripperStatus:", gripper.status);
        telemetry.update();
    }
}
