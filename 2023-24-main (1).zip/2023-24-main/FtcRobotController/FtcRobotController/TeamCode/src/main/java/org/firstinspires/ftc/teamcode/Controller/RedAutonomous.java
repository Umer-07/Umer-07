package org.firstinspires.ftc.teamcode.Controller;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.Arm.Elbow;
import org.firstinspires.ftc.teamcode.Arm.Gripper;
import org.firstinspires.ftc.teamcode.Arm.Shoulder;
import org.firstinspires.ftc.teamcode.Arm.Wrist;
import org.firstinspires.ftc.teamcode.Movement.MoveDaRobot;

@Autonomous
public class RedAutonomous extends LinearOpMode {
    MoveDaRobot moveDaRobot;
    Shoulder shoulder;
    Wrist wrist;
    Gripper gripper;
    Elbow elbow;
    private final ElapsedTime runtime = new ElapsedTime();
    static final double MOVE_SPEED = 0.4;

    @Override
    public void runOpMode() {

        moveDaRobot = new MoveDaRobot(hardwareMap, telemetry, gamepad1);
        gripper = new Gripper(hardwareMap, gamepad2);
        shoulder = new Shoulder(hardwareMap, gamepad2);
        wrist = new Wrist(hardwareMap, gamepad2);
        elbow = new Elbow(hardwareMap, gamepad2);
        moveDaRobot.init();

        // Send telemetry message to signify robot waiting;
        telemetry.addData("Status", "Ready to run");    //
        telemetry.update();

        // Wait for the game to start (driver presses PLAY)
        waitForStart();

        // Step 1:  Drive Right for 3 seconds
//        moveDaRobot.move(0.4, -0.4, -0.4, 0.4);
        moveDaRobot.moveRight(MOVE_SPEED);
        runtime.reset();
        while (opModeIsActive() && (runtime.seconds() < 2.75)) {
            telemetry.addData("Moving Right", "Step 1: %4.1f S Elapsed", runtime.seconds());
            telemetry.update();
        }
        moveDaRobot.stop();

        // Step 2:  Lower Arm and Wrist
        wrist.wristDown();
        shoulder.move(-1);
        runtime.reset();
        while (opModeIsActive() && (runtime.seconds() < 2.5)) {
            telemetry.addData("Lowering the arm", "Step 2: %4.1f ms Elapsed", runtime.milliseconds());
            telemetry.update();
        }
        shoulder.stop();

        // Step 3: Drop pixels
        gripper.gripperOpen();

        sleep(1000);

        // Step 2:  Lower Arm and Wrist
        wrist.wristup();
        shoulder.move(1);
        runtime.reset();
        while (opModeIsActive() && (runtime.seconds() < 1.5)) {
            telemetry.addData("Lowering the arm", "Step 2: %4.1f ms Elapsed", runtime.milliseconds());
            telemetry.update();
        }
        shoulder.stop();
    }
}
