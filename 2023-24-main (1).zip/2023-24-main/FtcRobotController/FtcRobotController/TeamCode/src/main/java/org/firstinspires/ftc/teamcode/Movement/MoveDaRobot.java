package org.firstinspires.ftc.teamcode.Movement;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public class MoveDaRobot {
    private DcMotor RightFrontMotor;
    private DcMotor LeftFrontMotor;
    private DcMotor RightBackMotor;
    private DcMotor LeftBackMotor;
    double leftFront;
    double rightFront;
    double leftBack;
    double rightBack;

    public double POWER_ADJUST_UNIT = 0.2;

    public double POWER_ADJUST_MAX = 0.9;

    public double POWER_ADJUST_MIN = 0.2;

    public int GAMEPAD_RUMBLE_SHORT = 150; // 250 ms

    public int GAMEPAD_RUMBLE_LONG = 250; // 500 ms

    private double scaledPower = POWER_ADJUST_MIN;

    public static double SENSITIVITY_LEVEL = 10.0;

    //private double TURN_SPEED_SCALE_FACTOR = scaledPower; // 0.8;

    //private double X_Y_SPEED_SCALE_FACTOR = scaledPower; // 0.8;

    private HardwareMap hardwareMap;

    private Telemetry telemetry;

    private Gamepad gamepad;

    private Gamepad prevGamepad;



    public MoveDaRobot(HardwareMap hardwareMap, Telemetry telemetry, Gamepad gamepad) {
        this.hardwareMap = hardwareMap;
        this.telemetry = telemetry;
        this.gamepad = gamepad;
    }

    public void init() {
        RightFrontMotor = hardwareMap.get(DcMotor.class, "rightFront");
        RightFrontMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        LeftFrontMotor = hardwareMap.get(DcMotor.class, "leftFront");
        LeftFrontMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        LeftFrontMotor.setDirection(DcMotorSimple.Direction.REVERSE);

        RightBackMotor = hardwareMap.get(DcMotor.class, "rightBack");
        RightBackMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        LeftBackMotor = hardwareMap.get(DcMotor.class, "leftBack");
        LeftBackMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        LeftBackMotor.setDirection(DcMotorSimple.Direction.REVERSE);

        // Init prev and current gamepad state as the same
        prevGamepad = new Gamepad();
        prevGamepad.copy(gamepad);

        scaledPower = POWER_ADJUST_MIN;

        telemetry.addData("Status", "Initialized");
        telemetry.update();
    }

    public void loop() {
        double x;
        double y;
        double turn;
        double thetaRadians;
        double thetaDegrees;
        double power;
        double sin;
        double cos;
        double max;

        x = gamepad.left_stick_x * scaledPower;
        y = -gamepad.left_stick_y * scaledPower;
        turn = gamepad.right_stick_x * scaledPower;

        // Make sure power is always in range
        if (scaledPower < POWER_ADJUST_MIN) {
            scaledPower = POWER_ADJUST_MIN;
        }

        if (scaledPower > POWER_ADJUST_MAX) {
            scaledPower = POWER_ADJUST_MAX;
        }

        // Adjust power up
        if (!prevGamepad.right_bumper && gamepad.right_bumper) {
            if ((scaledPower >= POWER_ADJUST_MIN) && (scaledPower < POWER_ADJUST_MAX)) {
                scaledPower += POWER_ADJUST_UNIT;
                gamepad.setLedColor(0.0, 1.0, 0.0, GAMEPAD_RUMBLE_LONG);
                gamepad.rumble(GAMEPAD_RUMBLE_LONG);
            }
        }

        // Adjust power down
        if (!prevGamepad.left_bumper && gamepad.left_bumper) {
            if ((scaledPower > POWER_ADJUST_MIN) && (scaledPower <= POWER_ADJUST_MAX)) {
                scaledPower -= POWER_ADJUST_UNIT;
                gamepad.setLedColor(1.0, 0.0, 0.0, GAMEPAD_RUMBLE_SHORT);
                gamepad.rumble(GAMEPAD_RUMBLE_SHORT);
            }
        }
/*
        if (!gamepad.right_bumper) {
            y /= 2;
            x /= 2;
            turn /= 2;
        }
 */
        thetaRadians = Math.atan2(y, x);
        thetaDegrees = round(Math.toDegrees(thetaRadians));
        thetaRadians = Math.toRadians(thetaDegrees);
        power = Math.hypot(x, y);

        sin = Math.sin(thetaRadians - Math.PI / 4);
        cos = Math.cos(thetaRadians - Math.PI / 4);
        max = Math.max(Math.abs(sin), Math.abs(cos));

        leftFront = power * cos / max + turn;
        rightFront = power * sin / max - turn;
        leftBack = power * sin / max + turn;
        rightBack = power * cos / max - turn;

        // Scale the power
        power *= scaledPower;

        // Scale the turn
        turn *= scaledPower;

        if ((power + Math.abs(turn)) > 1) {
            leftFront /= power + Math.abs(turn);
            rightFront /= power + Math.abs(turn);
            leftBack /= power + Math.abs(turn);
            rightBack /= power + Math.abs(turn);
        }

        move(leftFront, rightFront, leftBack, rightBack);

        // Copy gamepad state
        prevGamepad.copy(gamepad);

        thetaDegrees = Math.toDegrees(thetaRadians);

        telemetry.addData("x:", String.valueOf(x));
        telemetry.addData("y:", String.valueOf(y));
        telemetry.addData("Theta:", String.valueOf(thetaDegrees));
        telemetry.addData("Power:", String.valueOf(power));

        telemetry.addData("leftFront:", String.valueOf(leftFront));
        telemetry.addData("rightFront:", String.valueOf(rightFront));
        telemetry.addData("leftBack:", String.valueOf(leftBack));
        telemetry.addData("rightBack:", String.valueOf(rightBack));
        telemetry.addData("turn:", String.valueOf(turn));
        telemetry.addData("scaledPower:", String.valueOf(scaledPower * 100));
        telemetry.addData("leftBumper:", String.valueOf(gamepad.left_bumper));
        telemetry.addData("rightBumper:", String.valueOf(gamepad.right_bumper));
    }

    public double round(double theta) {

        return Math.round(theta / SENSITIVITY_LEVEL) * SENSITIVITY_LEVEL;
    }

    public void move(double leftFront, double rightFront, double leftBack, double rightBack)
    {
        LeftFrontMotor.setPower(leftFront);
        RightFrontMotor.setPower(rightFront);
        LeftBackMotor.setPower(leftBack);
        RightBackMotor.setPower(rightBack);
    }

    public void moveRight(double speed)
    {
        LeftFrontMotor.setPower(speed);
        RightFrontMotor.setPower(-speed);
        LeftBackMotor.setPower(-speed);
        RightBackMotor.setPower(speed);
    }
    public void moveLeft(double speed)
    {
        LeftFrontMotor.setPower(-speed);
        RightFrontMotor.setPower(speed);
        LeftBackMotor.setPower(speed);
        RightBackMotor.setPower(-speed);
    }
    public void stop() {
        move(0, 0, 0, 0);
    }

}
