package org.firstinspires.ftc.teamcode.Arm;

import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.robotcore.external.Telemetry;


public class testGripper {
    private ServoImplEx lGripper;
    private ServoImplEx rGripper;
    private boolean gripperIsOpen;
    private int servoCountdown;
    private Gamepad gamepad = null;
    private Gamepad prevGamepad = null;
    String gripperStatus = null;

    public void init(HardwareMap hardwareMap, Gamepad myGamepad){
        lGripper = hardwareMap.get(ServoImplEx.class, "leftGripper");
        lGripper.setPwmRange(new PwmControl.PwmRange(500, 2500));
        lGripper.scaleRange(0.2,0.45);
        rGripper = hardwareMap.get(ServoImplEx.class, "rightGripper");
        rGripper.setPwmRange(new PwmControl.PwmRange(500, 2500));
        rGripper.scaleRange(0.2,0.45);
        gamepad = myGamepad;
        prevGamepad = myGamepad;
        gripperStatus = new String();

        lGripper.setDirection(Servo.Direction.FORWARD);
        rGripper.setDirection(Servo.Direction.REVERSE);
    }


    public void gripperOpen(){
        lGripper.setPosition(1.0);
        rGripper.setPosition(1.0);
        gripperIsOpen = true;
        servoCountdown = 400;
        gripperStatus += "open";
    }
    public void gripperClose(){
        lGripper.setPosition(0.0);
        rGripper.setPosition(0.0);
        gripperIsOpen = false;
        servoCountdown = 400;
        gripperStatus += "close";
    }
public void loop() {

    if (servoCountdown>0){
        servoCountdown -= 1;
        return;
    }

    if (gamepad.a && !gripperIsOpen && servoCountdown == 0) {
        gripperStatus += "a" + " " + String.valueOf(servoCountdown);
        gripperOpen();
    }
    else if (gamepad.y && gripperIsOpen && servoCountdown == 0) {
        gripperStatus += "y" + " " + String.valueOf(servoCountdown);
        gripperClose();
    } else {
        gripperStatus +=  " none a " + String.valueOf(gamepad.a) + " " + String.valueOf(servoCountdown);
    }


}

    /*public String loop() {
        String localStr = new String();

        if (gamepad.x) {
            //gripperStatus += "x" + " " + String.valueOf(servoCountdown);
        } else {
            //gripperStatus += "not a" + String.valueOf(servoCountdown);
        }

        if (gamepad.a && gripperIsOpen == false && servoCountdown == 0) {
            gripperStatus += "a" + " " + String.valueOf(servoCountdown);
            gripperOpen();
        }
        else if (gamepad.a && gripperIsOpen == true && servoCountdown == 0) {
            gripperStatus += "a" + " " + String.valueOf(servoCountdown);
            gripperClose();
        } else {
            gripperStatus +=  " none a " + String.valueOf(gamepad.a) + " " + String.valueOf(servoCountdown);
        }

        if (servoCountdown>0){
            servoCountdown -= 1;
        }

        prevGamepad.copy(gamepad);

        localStr = gripperStatus;
        gripperStatus = "";
        return localStr;
    }*/
}