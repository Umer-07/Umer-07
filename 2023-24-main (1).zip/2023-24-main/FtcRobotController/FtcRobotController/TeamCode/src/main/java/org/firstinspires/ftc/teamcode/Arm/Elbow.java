package org.firstinspires.ftc.teamcode.Arm;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class Elbow {
    private final DcMotor elbowMotor;
    private final Gamepad gamepad;
    public String status = "";
    private final int powerNum = 1;

    public Elbow(HardwareMap hardwareMap, Gamepad gamepad) {
        this.gamepad = gamepad;
        elbowMotor = hardwareMap.get(DcMotor.class, "elbowMotor");
    }

    public void loop() {
        if (gamepad.left_trigger > 0.0) {
            moveDown();
        } else if (gamepad.right_trigger > 0.0) {
            moveUp();
        } else {
            stop();
        }
    }

    public void moveUp() {

        elbowMotor.setPower(gamepad.right_trigger / powerNum);
        status = "Move Forward";
    }

    public void moveDown() {
        elbowMotor.setPower(-gamepad.left_trigger / powerNum);
        status = "Move Backward";
    }

    public void stop() {
        elbowMotor.setPower(0);
        status = "Stopped";
    }
}
