package org.firstinspires.ftc.teamcode.Arm;

import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;

public class Wrist {
    private ServoImplEx wrist;
    private boolean wristIsUp = true;
    private int servoCountdown;
    private Gamepad gamepad = null;
    public String status = "";

    public Wrist(HardwareMap hardwareMap, Gamepad gamepad) {
        wrist = hardwareMap.get(ServoImplEx.class, "wrist");
        wrist.setPwmRange(new PwmControl.PwmRange(500, 2500));
        wrist.setDirection(Servo.Direction.REVERSE);
        wrist.scaleRange(0.0,0.6);
        this.gamepad = gamepad;
    }

    public void wristup(){
        wrist.setPosition(1.0);
        wristIsUp = true;
        servoCountdown = 200;
        status = "up";
    }

    public void wristDown(){
        wrist.setPosition(0.0);
        wristIsUp = false;
        servoCountdown = 200;
        status = "down";
    }
    public void loop(){

        if (servoCountdown > 0) {
            servoCountdown --;
            return;
        }

        if (gamepad.x) {
            wristup();
        } else if (gamepad.b) {
            wristDown();
        }
        else {
            status = "idle";
        }
    }
}
